import { useState } from "react";

import ResumeUpload from "../components/ResumeUpload";
import SkillScore from "../components/SkillScore";
import SkillsFound from "../components/SkillsFound";
import MissingSkills from "../components/MissingSkills";
import ExperienceCard from "../components/ExperienceCard";
import Recommendations from "../components/Recommendations";
import Loading from "../components/Loading";

function Home({ darkMode }) {
  const [resume, setResume] = useState(null);
  const [loading, setLoading] = useState(false);
  const [analyzed, setAnalyzed] = useState(false);

  // Temporary dummy data
  const score = 82;

  const skills = [
    "JavaScript",
    "React",
    "Node.js",
    "Express.js",
    "MongoDB",
    "Git",
    "REST APIs",
  ];

  const missingSkills = [
    "TypeScript",
    "Docker",
    "AWS",
    "CI/CD",
  ];

  const recommendations = [
    "Add measurable achievements to your work experience.",
    "Highlight your backend development experience.",
    "Consider adding TypeScript to your skill set.",
    "Add cloud technologies such as AWS if you have experience with them.",
  ];

  const analyzeResume = () => {
    if (!resume) return;

    setLoading(true);
    setAnalyzed(false);

    // Temporary simulation
    setTimeout(() => {
      setLoading(false);
      setAnalyzed(true);
    }, 1500);
  };

  return (
    <div className="max-w-6xl mx-auto p-8">

      {/* Header */}
      <div className="mb-8">
        <h2
          className={`text-3xl md:text-4xl font-bold mb-3 ${
            darkMode ? "text-purple-300" : "text-purple-800"
          }`}
        >
          AI Resume Skill Validator
        </h2>

        <p
          className={`text-lg ${
            darkMode ? "text-slate-400" : "text-slate-600"
          }`}
        >
          Upload your resume and discover your strengths,
          skill gaps, and opportunities for improvement.
        </p>
      </div>

      {/* Upload Card */}
      <div
        className={`rounded-2xl shadow-xl p-8 border ${
          darkMode
            ? "bg-slate-900 border-slate-800"
            : "bg-white border-purple-100"
        }`}
      >
        <ResumeUpload
          darkMode={darkMode}
          resume={resume}
          setResume={setResume}
        />

        {resume && (
          <button
            onClick={analyzeResume}
            disabled={loading}
            className="mt-6 w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 disabled:opacity-60 text-white py-3 rounded-xl font-semibold shadow-lg transition"
          >
            {loading
              ? "Analyzing Resume..."
              : "✦ Analyze Resume"}
          </button>
        )}
      </div>

      {/* Loading */}
      {loading && (
        <Loading darkMode={darkMode} />
      )}

      {/* Results */}
      {analyzed && !loading && (
        <div className="mt-10">

          <div className="mb-6">
            <h2
              className={`text-2xl font-bold ${
                darkMode
                  ? "text-white"
                  : "text-slate-800"
              }`}
            >
              Resume Analysis
            </h2>

            <p
              className={
                darkMode
                  ? "text-slate-400"
                  : "text-slate-500"
              }
            >
              Here's what we found in your resume.
            </p>
          </div>

          {/* Score + Skills */}
          <div className="grid md:grid-cols-3 gap-6">

            <SkillScore
              darkMode={darkMode}
              score={score}
            />

            <div className="md:col-span-2">
              <SkillsFound
                darkMode={darkMode}
                skills={skills}
              />
            </div>

          </div>

          {/* Missing Skills */}
          <div className="mt-6">
            <MissingSkills
              darkMode={darkMode}
              skills={missingSkills}
            />
          </div>

          {/* Experience */}
          <div className="mt-6">
            <ExperienceCard
              darkMode={darkMode}
              experience="1+ Years"
              education="BS Computer Science"
            />
          </div>

          {/* Recommendations */}
          <div className="mt-6">
            <Recommendations
              darkMode={darkMode}
              recommendations={recommendations}
            />
          </div>

        </div>
      )}

    </div>
  );
}

export default Home;