function Navbar({ darkMode, setDarkMode }) {
  return (
    <nav
      className={`px-8 py-4 shadow-md ${
        darkMode
          ? "bg-slate-950 text-white"
          : "bg-indigo-700 text-white"
      }`}
    >
      <div className="max-w-6xl mx-auto flex items-center justify-between">

        {/* Logo / Project Name */}
        <div>
          <h1 className="text-2xl font-bold">
            ResumeAI
          </h1>

          <p className="text-xs opacity-80">
            AI Resume Analyzer
          </p>
        </div>

        {/* Right Side */}
        <div className="flex items-center gap-4">

          <span className="hidden md:block text-sm opacity-90">
            Analyze • Improve • Succeed
          </span>

          <button
            onClick={() => setDarkMode(!darkMode)}
            className="px-4 py-2 rounded-lg bg-white/10 hover:bg-white/20 transition"
          >
            {darkMode ? "☀️ Light" : "🌙 Dark"}
          </button>

        </div>
      </div>
    </nav>
  );
}

export default Navbar;