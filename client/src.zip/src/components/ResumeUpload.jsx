function ResumeUpload({ darkMode, resume, setResume }) {
  const handleFileChange = (e) => {
    const file = e.target.files[0];

    if (file) {
      setResume(file);
    }
  };

  return (
    <div
      className={`border-2 border-dashed rounded-2xl p-10 text-center ${
        darkMode
          ? "border-purple-700 bg-slate-950"
          : "border-purple-300 bg-purple-50"
      }`}
    >
      <div className="text-5xl mb-5">📄</div>

      <h3
        className={`text-xl font-semibold mb-2 ${
          darkMode ? "text-white" : "text-slate-800"
        }`}
      >
        Upload Your Resume
      </h3>

      <p
        className={`mb-6 ${
          darkMode ? "text-slate-400" : "text-slate-500"
        }`}
      >
        Upload your resume in PDF format
      </p>

      <label className="inline-block bg-purple-600 hover:bg-purple-700 text-white px-6 py-3 rounded-xl cursor-pointer transition shadow-md">
        📁 Choose Resume

        <input
          type="file"
          accept=".pdf"
          onChange={handleFileChange}
          className="hidden"
        />
      </label>

      {resume && (
        <div
          className={`mt-6 p-4 rounded-xl ${
            darkMode ? "bg-slate-900" : "bg-white"
          }`}
        >
          <p
            className={`font-medium ${
              darkMode ? "text-green-400" : "text-green-600"
            }`}
          >
            ✅ Resume Selected
          </p>

          <p
            className={`text-sm mt-1 ${
              darkMode ? "text-slate-400" : "text-slate-500"
            }`}
          >
            {resume.name}
          </p>
        </div>
      )}
    </div>
  );
}

export default ResumeUpload;